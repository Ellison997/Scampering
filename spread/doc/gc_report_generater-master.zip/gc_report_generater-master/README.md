# gc_report_generater

安装nodejs
https://nodejs.org/zh-cn/

在命令行（cmd）运行以下命令

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

访问localhost:3000


### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
