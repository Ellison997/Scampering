package com.grapecity.reportserver.Model.MocData;

public class EquipmentInfo {
    public String 计量标准名称;
    public String 计量标准测量范围;
    public String 计量标准等级;
    public String 计量标准证书号;
    public String 计量标准有效期至;
}
