package com.grapecity.reportserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GCReportServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(GCReportServerApplication.class, args);
    }

}
